Third party licenses by different vendors:
=========================================

H2 : Mozilla Public License, Version 2.0 - H2 Group

JSch : BSD License - Atsuhiko Yamanaka, JCraft,Inc

Google-Gson : Apache License, Version 2.0 - Google, Inc.

Apache Commons FileUpload : Apache License, Version 2.0 -  The Apache Software Foundation

Apache Commons Codec : Apache License, Version 2.0 -  The Apache Software Foundation

Apache Commons DBCP : Apache License, Version 2.0 -  The Apache Software Foundation

Apache Commons Configuration : Apache License, Version 2.0 -  The Apache Software Foundation

Apache Commons Lang: Apache License, Version 2.0 -  The Apache Software Foundation

Apache Commons Log4j 2: Apache License, Version 2.0 -  The Apache Software Foundation

SLF4J : MIT License - QOS.ch

Thymeleaf: Apache License, Version 2.0 -  The THYMELEAF team

ZXing : Apache License, Version 2.0 -  ZXing Authors

Bootstrap : MIT License - Twitter, Inc.

jQuery : MIT License - jQuery Foundation, Inc.

jQueryUI : MIT License - jQuery Foundation, Inc.

jquery.floatThead : MIT License - Misha Koryak

xterm.js : MIT License - The xterm.js authors 
